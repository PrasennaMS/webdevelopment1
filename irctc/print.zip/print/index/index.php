<?php
    $connect = mysqli_connect('localhost', 'root', '', 'sp');
    $retrieve=mysqli_query($connect,"select * from register where name='divya' and email='divs@gmail.com'");
    $show=mysqli_fetch_array($retrieve,MYSQLI_ASSOC);
    $nums=mysqli_num_rows($retrieve);
    if($nums==1)
    {
    echo '<table border="2" class="table table-hover"><tr><th ><span>Name</span> </th><td><span>'.$show['name'].'<span></td>';
    echo '<tr><th><span>Reg no</span></th><td><span>'. $show['reg_no'].'</span></td>';
    
    echo '<tr><th><span>Email </span></th><td><span>'. $show['email'].'</span></td>';
    echo '<tr><th><span>DOB</span></th><td><span>'. $show['dob'].'</span></td>';
    echo '<tr><th><span>Mobile</span></th><td><span>'. $show['mobile'].'</span></td>';
    echo '<tr><th><span>Package</span></th><td><span>'. $show['course'].'</span></td></tr></table>';
    }
    ?>
    <html>
    <head><title>print</title> <link rel="stylesheet" type="text/css" href="../css/print.css" media="print"></head>
    <body>
    <div class="text-center">
        <button onclick="window.print();" class="btn btn-primary" id="print-btn">Print</button>
    </div>
</body>
</html>
