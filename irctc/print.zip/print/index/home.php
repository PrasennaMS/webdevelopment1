<?php
$connect = mysqli_connect('localhost', 'root', '', 'test');
$retrieve=mysqli_query($connect,"select * from details where name='Divya S'");
$show=mysqli_fetch_array($retrieve,MYSQLI_ASSOC);
$num=mysqli_num_rows($retrieve);
// if($num==1)
// {
//     echo 'connected';
// }
// else
// {
//     echo 'not connected';
// }
?>
<html>
    <head>
        <title>Vebbox Student's Form</title>
        <link rel="stylesheet" href="../css/print.css">
    </head>
    <body>
        <!-- main div start -->
        <div id="conatiner">
            <!-- logo img div start -->
            <div>
             <img id="logo" src="../image/logov (2).jpeg">
            </div>
            <!-- end logo img div -->
            <!-- logo name div start -->
            <div>
                <p id="logo_name">Vebbox Software Solutions</p>
            </div>
            <!-- logo name div end -->
            <!-- form div start -->
            <div id="form_std">
                <!-- profile div start -->
                <div>
                    <img src="../image/<?php echo $show['img'];?>" style="float: right;margin-right:2%;"height="15%" width="20%">
                </div>
                <!-- profile div end -->
                    <form action="" method="POST">
                        <div id="sub_form">
                            <label>Name</label>
                            <input type="text" value="<?php echo $show['name'];?>"style="width: 55%;">
                        </div>
                        <div id="sub_form">
                            <label>Date of Birth</label>
                            <input type="text" value="<?php echo $show['dob'];?>" style="width: 50%;">
                        </div>
                        <div id="sub_form">
                            <label>Gender</label>
                            <input type="text" value="<?php echo $show['gender'];?>" style="width: 55%;">
                        </div>
                        <div id="sub_form">
                            <label>Father's Name</label>
                            <input type="text" value="<?php echo $show['father'];?>"style="width: 48%;">
                        </div>
                        <div id="sub_form">
                            <label>Mother's Name</label>
                            <input type="text" value="<?php echo $show['mother'];?>" style="width: 48%;">
                        </div>
                        <div id="sub_form">
                            <label>Parent's Ocuupation</label>
                            <input type="text" value="<?php echo $show['occupation'];?>" style="width: 43%;">
                        </div>
                        <div id="sub_form">
                            <label>Address</label>
                            <input type="text" value="<?php echo $show['address'];?>" style="width: 55%;">
                        </div>
                        <div id="sub_form">
                            <label>Contact NO</label>
                            <input type="text" value="<?php echo $show['mob'];?>" style="width: 52%;">
                        </div>
                        <div id="sub_form">
                            <label>Email</label>
                            <input type="text" value="<?php echo $show['email'];?>" style="width: 65%;">
                        </div>
                        <!-- education div -->
                        <div>
                            <div id="edu_form">
                                <p>EDUCATION(Last exam passed)</p>
                            </div>
                            <div id="tab_edu">
                                <table id="edu_details">
                                    <tr>
                                        <th>EXAM PASSED</th>
                                        <th>BOARD/UNIVERSITY</th>
                                        <th>YEAR OF PASSING</th>
                                    </tr>
                                    <tr>
                                        <td><?php echo $show['degree'];?></td>
                                        <td><?php echo $show['insit'];?></td>
                                        <td><?php echo $show['pass'];?></td>
                                    </tr>
                                </table>
                            </div>
                            <!-- end education div -->
                        </div>
                        
                        <!-- course details start -->
                        <div id="tab_edu">
                            <div id="edu_form">
                                <label>COURSE DETAILS</label>
                                
                            </div>
                            <div style="padding:1%;">
                                <label>COURSE NAME:</label>
                                <span style="padding:0%;"><?php echo $show['course'];?></span>
                            </div>
                            <div style="padding:1%;">
                                <label>COURSE DURATIONS:</label>
                                <span style="padding:2%;"><?php echo $show['durations'];?></span>
                            </div>
                            <div style="margin-top:-7%;float:right;">
                                <label>BATCH TIMING:</label>
                                <span style="padding:0%;"><?php echo $show['batchtime'];?></span>
                            </div>
                            <div style="padding:1%;">
                                <label>DATE:</label>
                                <span style="padding:1%;"><?php echo $show['date'];?></span>
                            </div>
                            <div style="margin-top:-3%;float:right;">
                                <label>PLACE:</label>
                                <span style="padding:0%;"><?php echo $show['place'];?></span>
                            </div>
                        </div>
                    </form>
                </div>
                <!-- form div end -->

        <button onclick="window.print();"  >Print</button>

            </div>
            <!-- main div end -->
        </div>
        
    </body>
</html>